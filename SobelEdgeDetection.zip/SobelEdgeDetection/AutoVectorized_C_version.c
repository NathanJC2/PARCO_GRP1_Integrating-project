
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#define BENCHMARK_RUNS 30
#define KERNEL_REPETITIONS 100

// reads one token at a time from the PGM image file
static int read_pgm_token(FILE *file, char *token, size_t token_size)
{
    int ch;
    size_t length = 0;

    // skips whitespace and comments
    do {
        ch = fgetc(file);
        if (ch == '#') {
            do {
                ch = fgetc(file);
            } while (ch != '\n' && ch != EOF);
        }
    } while (ch != EOF && isspace((unsigned char)ch));

    // checks for end of file
    if (ch == EOF) {
        return 0;
    }

    // extracts the token
    while (ch != EOF && !isspace((unsigned char)ch)) {
        if (length + 1 >= token_size) {
            return 0;
        }
        token[length] = (char)ch;
        length = length + 1;
        ch = fgetc(file);
    }

    // handles Windows-style line endings
    if (ch == '\r') {
        int next = fgetc(file);

        if (next != '\n' && next != EOF) {
            ungetc(next, file);
        }
    }
    token[length] = '\0';
    return length > 0;
}

// converts a string into a numerical image dimension
static int parse_size(const char *token, size_t *value)
{
    char *end;
    unsigned long long parsed;

    // converts the string into an unsigned long long integer
    errno = 0;
    parsed = strtoull(token, &end, 10);

    // validates the converted dimension
    if (errno != 0 || *token == '\0' || *token == '-' ||
        *end != '\0' || parsed == 0 || parsed > SIZE_MAX) {
        return 0;
    }

    // stores the dimension
    *value = (size_t)parsed;

    return 1;
}

// parses a string into a grayscale pixel value
static int parse_pixel(const char *token, uint8_t *value)
{
    char *end;
    unsigned long parsed;

    // converts the string into an unsigned long integer
    errno = 0;
    parsed = strtoul(token, &end, 10);

    // validates the pixel value
    if (errno != 0 || *token == '\0' || *token == '-' ||
        *end != '\0' || parsed > 255) {
        return 0;
    }

    // stores the pixel value
    *value = (uint8_t)parsed;

    return 1;
}

// loads a PGM image from a file into memory
static int read_pgm(const char *path, uint8_t **pixels,
                    size_t *width, size_t *height)
{
    FILE *file = fopen(path, "rb");
    char token[64];
    size_t pixel_count;
    uint8_t *data = NULL;
    int is_binary;
    int success = 0;

    // checks if the input file can be opened
    if (file == NULL) {
        fprintf(stderr, "Cannot open input image '%s'.\n", path);
        return 0;
    }

    // reads the image format
    if (!read_pgm_token(file, token, sizeof(token))) {
        fprintf(stderr, "Invalid PGM file '%s': missing image format.\n",
                path);
        goto cleanup;
    }

    if (strcmp(token, "P5") == 0) {
        is_binary = 1;
    } else if (strcmp(token, "P2") == 0) {
        is_binary = 0;
    } else {
        fprintf(stderr, "Unsupported image format in '%s'.\n", path);
        goto cleanup;
    }

    // reads and validates the image dimensions
    if (!read_pgm_token(file, token, sizeof(token)) ||
        !parse_size(token, width) ||
        !read_pgm_token(file, token, sizeof(token)) ||
        !parse_size(token, height)) {
        fprintf(stderr, "Invalid PGM dimensions in '%s'.\n", path);
        goto cleanup;
    }

    // checks for integer overflow when calculating the pixel count
    if (*width > SIZE_MAX / *height) {
        fprintf(stderr, "Image dimensions in '%s' are too large.\n", path);
        goto cleanup;
    }

    // calculates the total number of pixels
    pixel_count = *width * *height;

    // checks the maximum pixel value
    if (!read_pgm_token(file, token, sizeof(token)) ||
        strcmp(token, "255") != 0) {
        fprintf(stderr, "Unsupported maximum pixel value in '%s'.\n", path);
        goto cleanup;
    }

    // allocates memory for the image pixels
    data = (uint8_t *)malloc(pixel_count);

    if (data == NULL) {
        fprintf(stderr, "Not enough memory to read '%s'.\n", path);
        goto cleanup;
    }

    // reads binary pixel data
    if (is_binary) {
        if (fread(data, 1, pixel_count, file) != pixel_count) {
            fprintf(stderr, "Image data in '%s' is incomplete.\n", path);
            goto cleanup;
        }
    } else {

        // reads ASCII pixel data
        size_t i;

        for (i = 0; i < pixel_count; i = i + 1) {
            if (!read_pgm_token(file, token, sizeof(token)) ||
                !parse_pixel(token, &data[i])) {
                fprintf(stderr,
                        "Invalid or incomplete pixel data in '%s'.\n",
                        path);
                goto cleanup;
            }
        }
    }

    // transfers the loaded image data to the caller
    *pixels = data;
    data = NULL;
    success = 1;

// releases allocated memory and closes the file
cleanup:
    free(data);
    fclose(file);

    return success;
}

// saves the processed image into a PGM file
static int write_pgm(const char *path, const uint8_t *pixels,
                     size_t width, size_t height)
{
    FILE *file = fopen(path, "wb");
    size_t pixel_count = width * height;
    int success = 0;

    // checks if the output file can be opened
    if (file == NULL) {
        fprintf(stderr, "Cannot open output image '%s'.\n", path);
        return 0;
    }

    // writes the image header and pixel data
    if (fprintf(file, "P5\n%zu %zu\n255\n", width, height) < 0 ||
        fwrite(pixels, 1, pixel_count, file) != pixel_count) {
        fprintf(stderr, "Failed to write output image '%s'.\n", path);
    } else {
        success = 1;
    }

    // closes the output file
    if (fclose(file) != 0) {
        fprintf(stderr, "Failed to finish writing output image '%s'.\n",
                path);
        success = 0;
    }

    return success;
}

// performs auto-vectorization-friendly Sobel edge detection
#if defined(__GNUC__)
__attribute__((noinline))
#endif
static int sobel_autovectorized(const uint8_t *input, uint8_t *output,
                                size_t width, size_t height)
{
    size_t y;
    size_t pixel_count;

    // validates the input parameters
    if (input == NULL || output == NULL ||
        width == 0 || height == 0 ||
        width > SIZE_MAX / height || input == output) {
        return 0;
    }

    // calculates the total number of pixels
    pixel_count = width * height;

    // initializes the output buffer and sets the borders to zero
    memset(output, 0, pixel_count);

    // handles images smaller than 3 x 3
    if (width < 3 || height < 3) {
        return 1;
    }

    // iterates over the image rows and calculates row offsets
    for (y = 1; y < height - 1; y = y + 1) {
        size_t x;
        size_t top = (y - 1) * width;
        size_t middle = y * width;
        size_t bottom = (y + 1) * width;

        // hints to GCC that iterations of this loop have
        // no loop-carried dependencies that prevent vectorization
        #if defined(__GNUC__)
        #pragma GCC ivdep
        #endif
        for (x = 1; x < width - 1; x = x + 1) {

            // calculates the horizontal gradient
            int gx =
                -(int)input[top + x - 1] + (int)input[top + x + 1]
                - 2 * (int)input[middle + x - 1]
                + 2 * (int)input[middle + x + 1]
                - (int)input[bottom + x - 1]
                + (int)input[bottom + x + 1];

            // calculates the vertical gradient
            int gy =
                -(int)input[top + x - 1] - 2 * (int)input[top + x]
                - (int)input[top + x + 1]
                + (int)input[bottom + x - 1]
                + 2 * (int)input[bottom + x]
                + (int)input[bottom + x + 1];

            // calculates the squared gradient magnitude
            unsigned int squared_magnitude =
                (unsigned int)(gx * gx + gy * gy);

            // calculates the rounded gradient magnitude
            unsigned int magnitude =
                (unsigned int)(sqrt((double)squared_magnitude) + 0.5);

            // clamps the pixel value to the range 0 to 255
            if (magnitude > 255U) {
                magnitude = 255U;
            }

            // stores the final pixel value
            output[middle + x] = (uint8_t)magnitude;
        }
    }

    return 1;
}

int main(int argc, char **argv)
{
    uint8_t *input = NULL;
    uint8_t *output = NULL;
    size_t width;
    size_t height;

    // checks the command-line arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <input.pgm> <output.pgm>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // loads the input image before benchmarking
    if (!read_pgm(argv[1], &input, &width, &height)) {
        return EXIT_FAILURE;
    }

    // allocates memory for the output image
    output = (uint8_t *)malloc(width * height);

    if (output == NULL) {
        fprintf(stderr, "Not enough memory to create the output image.\n");
        free(input);
        return EXIT_FAILURE;
    }

    {
        double times[BENCHMARK_RUNS];
        double total_time = 0.0;
        double average_time;
        double median_time;
        double variance = 0.0;
        double standard_deviation;
        double temp;
        clock_t start;
        clock_t end;
        int run;
        int repetition;
        int i;
        int j;

        // performs one warm-up execution
        if (!sobel_autovectorized(input, output, width, height)) {
            fprintf(stderr, "Could not process the image.\n");
            free(output);
            free(input);
            return EXIT_FAILURE;
        }

        // collects 30 samples, each containing 100 kernel executions
        for (run = 0; run < BENCHMARK_RUNS; run = run + 1) {
            start = clock();

            // checks whether the start time is available
            if (start == (clock_t)-1) {
                fprintf(stderr, "Timing is unavailable.\n");
                free(output);
                free(input);
                return EXIT_FAILURE;
            }

            for (repetition = 0;
                 repetition < KERNEL_REPETITIONS;
                 repetition = repetition + 1) {
                if (!sobel_autovectorized(input, output, width, height)) {
                    fprintf(stderr, "Could not process the image.\n");
                    free(output);
                    free(input);
                    return EXIT_FAILURE;
                }
            }

            // records the end time
            end = clock();

            // checks whether the end time is available
            if (end == (clock_t)-1) {
                fprintf(stderr, "Timing is unavailable.\n");
                free(output);
                free(input);
                return EXIT_FAILURE;
            }

            // calculates the average time for this sample
            times[run] =
                ((double)(end - start) / CLOCKS_PER_SEC)
                / KERNEL_REPETITIONS;

            total_time = total_time + times[run];
        }

        // calculates the average time per execution
        average_time = total_time / BENCHMARK_RUNS;

        // sorts the samples to calculate the median
        for (i = 0; i < BENCHMARK_RUNS - 1; i = i + 1) {
            for (j = 0; j < BENCHMARK_RUNS - i - 1; j = j + 1) {
                if (times[j] > times[j + 1]) {
                    temp = times[j];
                    times[j] = times[j + 1];
                    times[j + 1] = temp;
                }
            }
        }

        // calculates the median time per execution
        median_time =
            (times[BENCHMARK_RUNS / 2 - 1]
             + times[BENCHMARK_RUNS / 2]) / 2.0;

        // calculates the population standard deviation
        for (i = 0; i < BENCHMARK_RUNS; i = i + 1) {
            double difference = times[i] - average_time;
            variance = variance + difference * difference;
        }

        standard_deviation = sqrt(variance / BENCHMARK_RUNS);

        // displays the benchmark results
        printf("\nAuto-vectorized Sobel Benchmark (%zu x %zu)\n",
               width, height);
        printf("Benchmark samples: %d\n", BENCHMARK_RUNS);
        printf("Kernel repetitions per sample: %d\n",
               KERNEL_REPETITIONS);
        printf("Total timed kernel executions: %d\n",
               BENCHMARK_RUNS * KERNEL_REPETITIONS);
        printf("Average time per execution: %.9f seconds\n",
               average_time);
        printf("Median time per execution: %.9f seconds\n",
               median_time);
        printf("Standard deviation: %.9f seconds\n",
               standard_deviation);
    }

    // saves the processed image after benchmarking
    if (!write_pgm(argv[2], output, width, height)) {
        free(output);
        free(input);
        return EXIT_FAILURE;
    }

    // releases allocated memory
    free(output);
    free(input);

    return EXIT_SUCCESS;
}