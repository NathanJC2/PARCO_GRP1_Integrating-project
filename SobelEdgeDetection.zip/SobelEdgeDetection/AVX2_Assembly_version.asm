
default rel
bits 64

section .rodata
align 8
const_half: dq 0.5

section .text
global sobel_avx2

%ifidn __OUTPUT_FORMAT__, win64
    %define SCRATCH_GX 160
    %define SCRATCH_GY 192
%else
    %define SCRATCH_GX 0
    %define SCRATCH_GY 32
%endif

; int sobel_avx2(const uint8_t *input,
;                uint8_t *output,
;                size_t width,
;                size_t height);
;
; Returns 1 on success and 0 for invalid arguments.
; Input and output must be separate, non-overlapping buffers.

sobel_avx2:
    push rbp
    mov rbp, rsp

    push rbx
    push rsi
    push rdi
    push r12
    push r13
    push r14
    push r15

%ifidn __OUTPUT_FORMAT__, win64
    ; Reserve stack space for saved XMM registers and scratch data.
    sub rsp, 232

    movdqu [rsp + 0],   xmm6
    movdqu [rsp + 16],  xmm7
    movdqu [rsp + 32],  xmm8
    movdqu [rsp + 48],  xmm9
    movdqu [rsp + 64],  xmm10
    movdqu [rsp + 80],  xmm11
    movdqu [rsp + 96],  xmm12
    movdqu [rsp + 112], xmm13
    movdqu [rsp + 128], xmm14
    movdqu [rsp + 144], xmm15

    ; Windows x64 arguments:
    ; RCX = input, RDX = output, R8 = width, R9 = height.
    mov r12, rcx
    mov r13, rdx
    mov r14, r8
    mov r15, r9
%else
    ; System V AMD64 arguments:
    ; RDI = input, RSI = output, RDX = width, RCX = height.
    sub rsp, 64

    mov r12, rdi
    mov r13, rsi
    mov r14, rdx
    mov r15, rcx
%endif

    ; Validate pointers and dimensions.
    test r12, r12
    jz .invalid_input

    test r13, r13
    jz .invalid_input

    test r14, r14
    jz .invalid_input

    test r15, r15
    jz .invalid_input

    cmp r12, r13
    je .invalid_input

    ; Check whether width * height overflows 64-bit size_t.
    mov rax, r14
    mul r15

    test rdx, rdx
    jnz .invalid_input

    ; Clear the output buffer, including all image borders.
    mov rcx, rax
    mov rdi, r13
    xor eax, eax
    rep stosb

    ; Images smaller than 3 x 3 have no interior pixels.
    cmp r14, 3
    jb .success

    cmp r15, 3
    jb .success

    ; Initialize row pointers.
    ; RSI = top input row
    ; RDI = middle input row
    ; RBX = bottom input row
    ; RDX = output row
    mov rsi, r12
    lea rdi, [r12 + r14]
    lea rbx, [rdi + r14]
    lea rdx, [r13 + r14]

    ; Number of interior rows.
    mov r8, r15
    sub r8, 2

    ; Last interior column: width - 1.
    mov r9, r14
    dec r9

.row_loop:
    ; Begin at the first interior column.
    mov rcx, 1

    ; Vector processing requires at least 16 interior pixels.
    cmp r14, 18
    jb .scalar_cleanup

.vec_loop:
    ; Recalculate the last valid vector start.
    ; This is necessary because R10 is used during magnitude processing.
    mov r10, r14
    sub r10, 17

    ; Process 16 pixels only when the whole vector fits.
    cmp rcx, r10
    ja .scalar_cleanup

    ; Load and widen 16 unsigned pixels from each row.
    vpmovzxbw ymm0, [rsi + rcx - 1] ; Top-left
    vpmovzxbw ymm1, [rsi + rcx]     ; Top-middle
    vpmovzxbw ymm2, [rsi + rcx + 1] ; Top-right

    vpmovzxbw ymm3, [rdi + rcx - 1] ; Middle-left
    vpmovzxbw ymm4, [rdi + rcx + 1] ; Middle-right

    vpmovzxbw ymm5, [rbx + rcx - 1] ; Bottom-left
    vpmovzxbw ymm6, [rbx + rcx]     ; Bottom-middle
    vpmovzxbw ymm7, [rbx + rcx + 1] ; Bottom-right

    ; Gx = TR - TL + 2*(MR - ML) + BR - BL.
    vpsubw ymm8, ymm2, ymm0

    vpsubw ymm9, ymm4, ymm3
    vpaddw ymm9, ymm9, ymm9
    vpaddw ymm8, ymm8, ymm9

    vpsubw ymm9, ymm7, ymm5
    vpaddw ymm8, ymm8, ymm9

    ; Gy = BL + 2*BM + BR - TL - 2*TM - TR.
    vpaddw ymm10, ymm0, ymm2

    vpaddw ymm11, ymm1, ymm1
    vpaddw ymm10, ymm10, ymm11

    vpaddw ymm11, ymm5, ymm7

    vpaddw ymm12, ymm6, ymm6
    vpaddw ymm11, ymm11, ymm12

    vpsubw ymm9, ymm11, ymm10

    ; Save the 16 signed gradients in scratch memory.
    vmovdqu [rsp + SCRATCH_GX], ymm8
    vmovdqu [rsp + SCRATCH_GY], ymm9

    ; Calculate the magnitude of each pixel in this vector.
    ; The gradients are vectorized; square root and rounding are scalar.
    xor r11d, r11d

.vector_magnitude_loop:
    cmp r11, 16
    jae .vector_done

    ; Calculate Gx squared.
    movsx eax, word [rsp + SCRATCH_GX + r11 * 2]
    imul eax, eax

    ; Calculate Gy squared.
    movsx r10d, word [rsp + SCRATCH_GY + r11 * 2]
    imul r10d, r10d

    ; Squared magnitude = Gx*Gx + Gy*Gy.
    add eax, r10d

    ; Rounded magnitude = floor(sqrt(value) + 0.5).
    cvtsi2sd xmm0, eax
    sqrtsd xmm0, xmm0
    addsd xmm0, [rel const_half]
    cvttsd2si eax, xmm0

    ; Clamp the result to 255.
    cmp eax, 255
    jbe .vector_store

    mov eax, 255

.vector_store:
    ; Use one index register for the destination address.
    ; NASM does not allow [base + index1 + index2].
    lea r10, [rcx + r11]
    mov [rdx + r10], al

    inc r11
    jmp .vector_magnitude_loop

.vector_done:
    add rcx, 16
    jmp .vec_loop

.scalar_cleanup:
    ; Process any remaining interior pixels one at a time.
    cmp rcx, r9
    jae .next_row

    ; Gx = TR - TL - 2*ML + 2*MR - BL + BR.
    movzx eax, byte [rsi + rcx + 1]
    movzx r10d, byte [rsi + rcx - 1]
    sub eax, r10d

    movzx r10d, byte [rdi + rcx - 1]
    shl r10d, 1
    sub eax, r10d

    movzx r10d, byte [rdi + rcx + 1]
    shl r10d, 1
    add eax, r10d

    movzx r10d, byte [rbx + rcx - 1]
    sub eax, r10d

    movzx r10d, byte [rbx + rcx + 1]
    add eax, r10d

    ; Preserve Gx while calculating Gy.
    mov r11d, eax

    ; Gy = BL + 2*BM + BR - TL - 2*TM - TR.
    movzx eax, byte [rbx + rcx - 1]

    movzx r10d, byte [rbx + rcx]
    shl r10d, 1
    add eax, r10d

    movzx r10d, byte [rbx + rcx + 1]
    add eax, r10d

    movzx r10d, byte [rsi + rcx - 1]
    sub eax, r10d

    movzx r10d, byte [rsi + rcx]
    shl r10d, 1
    sub eax, r10d

    movzx r10d, byte [rsi + rcx + 1]
    sub eax, r10d

    ; Calculate Gx squared plus Gy squared.
    mov r10d, eax
    imul r10d, r10d

    mov eax, r11d
    imul eax, eax
    add eax, r10d

    ; Calculate and round the magnitude.
    cvtsi2sd xmm0, eax
    sqrtsd xmm0, xmm0
    addsd xmm0, [rel const_half]
    cvttsd2si eax, xmm0

    ; Clamp the result to 255.
    cmp eax, 255
    jbe .scalar_store

    mov eax, 255

.scalar_store:
    mov [rdx + rcx], al

    inc rcx
    jmp .scalar_cleanup

.next_row:
    ; Advance the row pointers.
    add rsi, r14
    add rdi, r14
    add rbx, r14
    add rdx, r14

    dec r8
    jnz .row_loop

.success:
    mov eax, 1
    jmp .epilogue

.invalid_input:
    xor eax, eax

.epilogue:
    vzeroupper

%ifidn __OUTPUT_FORMAT__, win64
    ; Restore the nonvolatile XMM registers.
    movdqu xmm6,  [rsp + 0]
    movdqu xmm7,  [rsp + 16]
    movdqu xmm8,  [rsp + 32]
    movdqu xmm9,  [rsp + 48]
    movdqu xmm10, [rsp + 64]
    movdqu xmm11, [rsp + 80]
    movdqu xmm12, [rsp + 96]
    movdqu xmm13, [rsp + 112]
    movdqu xmm14, [rsp + 128]
    movdqu xmm15, [rsp + 144]

    add rsp, 232
%else
    add rsp, 64
%endif

    pop r15
    pop r14
    pop r13
    pop r12
    pop rdi
    pop rsi
    pop rbx
    pop rbp
    ret
