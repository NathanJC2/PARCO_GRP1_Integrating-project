
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char *argv[])
{
    int width = 0;
    int height = 0;
    int channels = 0;
    unsigned char *image = NULL;
    FILE *output = NULL;
    size_t pixel_count = 0;
    size_t written = 0;
    int success = 1;

    if (argc != 3)
    {
        printf("Usage: %s input_image output.pgm\n", argv[0]);
        success = 0;
    }

    if (success == 1)
    {
        image = stbi_load(argv[1], &width, &height, &channels, 1);

        if (image == NULL)
        {
            printf("Error: Could not load input image.\n");
            success = 0;
        }
    }

    if (success == 1)
    {
        if (width <= 0 || height <= 0 ||
            (size_t)width > SIZE_MAX / (size_t)height)
        {
            printf("Error: Invalid image dimensions.\n");
            success = 0;
        }
        else
        {
            pixel_count = (size_t)width * (size_t)height;
        }
    }

    if (success == 1)
    {
        output = fopen(argv[2], "wb");

        if (output == NULL)
        {
            printf("Error: Could not create output file.\n");
            success = 0;
        }
    }

    if (success == 1)
    {
        if (fprintf(output, "P5\n%d %d\n255\n", width, height) < 0)
        {
            printf("Error: Could not write PGM header.\n");
            success = 0;
        }
    }

    if (success == 1)
    {
        written = fwrite(image, sizeof(unsigned char),
                         pixel_count, output);

        if (written != pixel_count)
        {
            printf("Error: Could not write all image pixels.\n");
            success = 0;
        }
    }

    if (output != NULL)
    {
        if (fclose(output) != 0)
        {
            printf("Error: Could not finish writing output file.\n");
            success = 0;
        }
    }

    if (image != NULL)
    {
        stbi_image_free(image);
    }

    if (success == 1)
    {
        printf("Conversion successful!\n");
        printf("Input: %s\n", argv[1]);
        printf("Output: %s\n", argv[2]);
        printf("Dimensions: %d x %d\n", width, height);
        printf("Format: 8-bit grayscale PGM (P5)\n");
    }

    return success == 1 ? 0 : 1;
}