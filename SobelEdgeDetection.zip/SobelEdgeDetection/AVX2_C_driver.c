#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define BENCHMARK_RUNS 30
#define KERNEL_REPETITIONS 100

int sobel_avx2(const uint8_t *input,
               uint8_t *output,
               size_t width,
               size_t height);


// reads one token from a PGM header
static int read_pgm_token(FILE *file, char *token, size_t capacity)
{
    int character;
    size_t length = 0;

    character = fgetc(file);

    while (character != EOF && isspace((unsigned char)character))
    {
        character = fgetc(file);
    }

    while (character == '#')
    {
        while (character != EOF &&
               character != '\n' &&
               character != '\r')
        {
            character = fgetc(file);
        }

        character = fgetc(file);

        while (character != EOF &&
               isspace((unsigned char)character))
        {
            character = fgetc(file);
        }
    }

    while (character != EOF &&
           !isspace((unsigned char)character) &&
           character != '#')
    {
        if (length + 1 >= capacity)
        {
            return 0;
        }

        token[length] = (char)character;
        length = length + 1;
        character = fgetc(file);
    }

    if (character == '#')
    {
        while (character != EOF &&
               character != '\n' &&
               character != '\r')
        {
            character = fgetc(file);
        }
    }
    else if (character == '\r')
    {
        int next_character = fgetc(file);

        if (next_character != '\n' && next_character != EOF)
        {
            ungetc(next_character, file);
        }
    }

    if (length == 0)
    {
        return 0;
    }

    token[length] = '\0';

    return 1;
}


// reads an 8-bit binary PGM image
static int read_pgm(const char *filename,
                    uint8_t **pixels,
                    size_t *width,
                    size_t *height)
{
    FILE *file;
    char token[64];
    char *end_pointer;
    unsigned long parsed_value;
    size_t pixel_count;
    uint8_t *buffer;
    size_t bytes_read;
    int success = 0;

    *pixels = NULL;
    *width = 0;
    *height = 0;

    file = fopen(filename, "rb");

    if (file == NULL)
    {
        printf("Error: Cannot open input file: %s\n", filename);
    }
    else
    {
        if (read_pgm_token(file, token, sizeof(token)) == 1 &&
            strcmp(token, "P5") == 0)
        {
            if (read_pgm_token(file, token, sizeof(token)) == 1)
            {
                parsed_value = strtoul(token, &end_pointer, 10);

                if (*token != '\0' &&
                    *end_pointer == '\0' &&
                    parsed_value > 0 &&
                    parsed_value <= SIZE_MAX)
                {
                    *width = (size_t)parsed_value;

                    if (read_pgm_token(file, token, sizeof(token)) == 1)
                    {
                        parsed_value = strtoul(token, &end_pointer, 10);

                        if (*token != '\0' &&
                            *end_pointer == '\0' &&
                            parsed_value > 0 &&
                            parsed_value <= SIZE_MAX)
                        {
                            *height = (size_t)parsed_value;

                            if (read_pgm_token(file, token,
                                               sizeof(token)) == 1 &&
                                strcmp(token, "255") == 0)
                            {
                                if (*width <= SIZE_MAX / *height)
                                {
                                    pixel_count = *width * *height;

                                    buffer = malloc(pixel_count);

                                    if (buffer != NULL)
                                    {
                                        bytes_read = fread(
                                            buffer,
                                            sizeof(uint8_t),
                                            pixel_count,
                                            file
                                        );

                                        if (bytes_read == pixel_count)
                                        {
                                            *pixels = buffer;
                                            success = 1;
                                        }
                                        else
                                        {
                                            printf(
                                                "Error: Incomplete PGM pixel data.\n"
                                            );

                                            free(buffer);
                                        }
                                    }
                                    else
                                    {
                                        printf(
                                            "Error: Cannot allocate input image.\n"
                                        );
                                    }
                                }
                                else
                                {
                                    printf(
                                        "Error: Image dimensions overflow.\n"
                                    );
                                }
                            }
                            else
                            {
                                printf(
                                    "Error: Expected an 8-bit P5 PGM image.\n"
                                );
                            }
                        }
                    }
                }
            }
        }
        else
        {
            printf("Error: Input must be a binary P5 PGM image.\n");
        }

        fclose(file);
    }

    if (success == 0)
    {
        free(*pixels);
        *pixels = NULL;
        *width = 0;
        *height = 0;
    }

    return success;
}

// writes an 8-bit binary PGM image
static int write_pgm(const char *filename,
                     const uint8_t *pixels,
                     size_t width,
                     size_t height)
{
    FILE *file;
    size_t pixel_count;
    size_t bytes_written;
    int success = 0;

    file = fopen(filename, "wb");

    if (file == NULL)
    {
        printf("Error: Cannot create output file: %s\n", filename);
    }
    else
    {
        fprintf(file, "P5\n%zu %zu\n255\n", width, height);

        pixel_count = width * height;

        bytes_written = fwrite(
            pixels,
            sizeof(uint8_t),
            pixel_count,
            file
        );

        if (bytes_written == pixel_count && fclose(file) == 0)
        {
            success = 1;
        }
        else
        {
            printf("Error: Failed to write output image.\n");
        }

        if (success == 0)
        {
            /* The file may already have been closed by fclose. */
        }
    }

    return success;
}

// sorts benchmark samples to calculate the median
static int compare_doubles(const void *first, const void *second)
{
    double first_value = *(const double *)first;
    double second_value = *(const double *)second;

    if (first_value < second_value)
    {
        return -1;
    }

    if (first_value > second_value)
    {
        return 1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    uint8_t *input = NULL;
    uint8_t *output = NULL;

    size_t width = 0;
    size_t height = 0;
    size_t pixel_count;

    int sample;
    int repetition;
    int success = 1;

    clock_t start;
    clock_t end;

    double elapsed;
    double total_time;
    double average_time;
    double median_time;
    double standard_deviation;
    double variance;

    double samples[BENCHMARK_RUNS];
    double sorted_samples[BENCHMARK_RUNS];

    if (argc != 3)
    {
        printf(
            "Usage: %s input.pgm output.pgm\n",
            argv[0]
        );

        return 1;
    }

    if (read_pgm(argv[1], &input, &width, &height) == 0)
    {
        success = 0;
    }

    if (success != 0)
    {
        pixel_count = width * height;
        output = malloc(pixel_count);

        if (output == NULL)
        {
            printf("Error: Cannot allocate output image.\n");
            success = 0;
        }
    }

    if (success != 0)
    {
        printf(
            "AVX2 Assembly Sobel Benchmark (%zu x %zu)\n",
            width,
            height
        );

        printf("Benchmark samples: %d\n", BENCHMARK_RUNS);
        printf(
            "Kernel repetitions per sample: %d\n",
            KERNEL_REPETITIONS
        );

        printf(
            "Total timed kernel executions: %d\n",
            BENCHMARK_RUNS * KERNEL_REPETITIONS
        );

        /* Warm up the assembly kernel before timing. */
        if (sobel_avx2(input, output, width, height) == 0)
        {
            printf("Error: AVX2 Sobel kernel rejected the input.\n");
            success = 0;
        }
    }

    if (success != 0)
    {
        for (sample = 0; sample < BENCHMARK_RUNS;
             sample = sample + 1)
        {
            start = clock();

            if (start == (clock_t)-1)
            {
                printf("Error: Cannot read the clock.\n");
                success = 0;
            }

            if (success != 0)
            {
                for (repetition = 0;
                     repetition < KERNEL_REPETITIONS;
                     repetition = repetition + 1)
                {
                    if (sobel_avx2(input, output, width, height) == 0)
                    {
                        printf("Error: AVX2 kernel execution failed.\n");
                        success = 0;
                    }
                }

                end = clock();

                if (end == (clock_t)-1)
                {
                    printf("Error: Cannot read the clock.\n");
                    success = 0;
                }

                if (success != 0)
                {
                    elapsed = (double)(end - start) / CLOCKS_PER_SEC;

                    samples[sample] =
                        elapsed / KERNEL_REPETITIONS;
                }
            }
        }
    }

    if (success != 0)
    {
        total_time = 0.0;

        for (sample = 0; sample < BENCHMARK_RUNS;
             sample = sample + 1)
        {
            total_time = total_time + samples[sample];
            sorted_samples[sample] = samples[sample];
        }

        average_time = total_time / BENCHMARK_RUNS;

        qsort(
            sorted_samples,
            BENCHMARK_RUNS,
            sizeof(double),
            compare_doubles
        );

        median_time =
            (sorted_samples[BENCHMARK_RUNS / 2 - 1] +
             sorted_samples[BENCHMARK_RUNS / 2]) / 2.0;

        variance = 0.0;

        for (sample = 0; sample < BENCHMARK_RUNS;
             sample = sample + 1)
        {
            elapsed = samples[sample] - average_time;
            variance = variance + elapsed * elapsed;
        }

        variance = variance / BENCHMARK_RUNS;
        standard_deviation = sqrt(variance);

        printf(
            "Average time per execution: %.9f seconds\n",
            average_time
        );

        printf(
            "Median time per execution: %.9f seconds\n",
            median_time
        );

        printf(
            "Standard deviation: %.9f seconds\n",
            standard_deviation
        );

        if (write_pgm(argv[2], output, width, height) == 0)
        {
            success = 0;
        }
        else
        {
            printf("Output image saved to: %s\n", argv[2]);
        }
    }

    free(input);
    free(output);

    if (success == 0)
    {
        return 1;
    }

    return 0;
}
